import blogModel from "../models/blogModel.js";


class BlogController{
    static getAllBlogs = async (req, res)=>{
        try {
            const fetchAllBlogs = await blogModel.find({user : req.user._id});
            return res.status(200).json(fetchAllBlogs)
            
        } catch (error) {
            return res.status(400).json({message: error.message});
        }
    };


 static addNewBlog = async (req, res) => {
    const { title, category, description } = req.body;

    // Validate required fields
    if (!title || !category || !description) {
        return res.status(400).json({ message: "Title, category, and description are required." });
    }

    // Validate file existence
    if (!req.file || !req.file.filename) {
        return res.status(400).json({ message: "Thumbnail is required." });
    }

    try {
        // Create a new blog instance
        const newBlog = new blogModel({
            title,
            description,
            category,
            thumbnail: req.file.filename,
            user: req.user._id, // Assumes `req.user` is populated by authentication middleware
        });

        // Save the blog to the database
        const savedBlog = await newBlog.save();

        // Return success response
        if (savedBlog) {
            return res.status(200).json({ message: "Blog added successfully." });
        } else {
            return res.status(500).json({ message: "Failed to add the blog. Please try again later." });
        }
    } catch (error) {
        // Handle server-side errors
        return res.status(500).json({ message: error.message });
    }
};



    
    static getSingleBlog = async (req, res)=>{
       const {id} = req.params;
       try {
        if(id){
            const fetchBlogsByID = await blogModel.findById(id);
            return res.status(200).json(fetchBlogsByID);
        }else{
            return res.status(400).json({message: "Invalid Url"});
        }
        
       } catch (error) {
         return res.status(400).json({message: error.message});
       }
    };
}

export default BlogController;