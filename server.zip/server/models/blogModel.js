import mongoose from "mongoose";

// Define the blog schema
const blogSchema = new mongoose.Schema({
    title: {
        type: String,
        // required: true,
    },
    category: {
        type: mongoose.Schema.Types.ObjectId, // Correct usage of ObjectId
        // ref: "categories", // Defines a reference to the "categories" collection
    },
    description: {
        type: String,
        // required: true, // Ensures a description must be provided
    },
    thumbnail: {
        type: String, // Field for storing the thumbnail URL or path
    },
    user: {
        type: mongoose.Schema.Types.ObjectId, // Correct usage of ObjectId
        // ref: "users", // Defines a reference to the "users" collection
    },
});

// Create the blog model
const blogModel = mongoose.model("blogs", blogSchema);

export default blogModel;
