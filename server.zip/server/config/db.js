import mongoose, { Mongoose } from "mongoose";

const connectToMongo = async () => {

    const res = await mongoose.connect("mongodb://localhost:27017/mern-blog-project");

    if(res){
        console.log("Database connected successfully");
    }

};


export default connectToMongo;